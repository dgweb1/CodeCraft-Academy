-- zonas.lua (actualizado)
local config = dofile(minetest.get_modpath("equipos") .. "/config.lua")

local M = {}

-- Lista de spawns (Lua index 1 == display "0")
local lista_spawns = {
    { nombre = "Spawn 0 (default)", pos = config.spawn_global_default }
}
local spawn_actual_index = 1 -- índice en lista_spawns (1 => display 0)

-- Parámetros
M.zonas_equipo = config.zonas_equipo -- definición estática (nombres, skins, materiales)
M.tamano = { x = config.zona_base_default, y = config.zona_altura_default, z = config.zona_base_default }
M.separacion = config.zona_separacion_default

local filas = 3
local columnas = 5
local offset_bajo_spawn = 35 -- altura relativa debajo del spawn para centros de zona

-- Persistencia (opcional): guarda lista_spawns y spawn_actual_index
local function archivo_path() return minetest.get_worldpath() .. "/equipos_spawns.mt" end

local function guardar_lista_spawns()
    local path = archivo_path()
    local f, err = io.open(path, "w")
    if not f then return false, "No se pudo abrir archivo: "..tostring(err) end
    local data = { lista = lista_spawns, index = spawn_actual_index }
    f:write(minetest.serialize(data))
    f:close()
    return true
end

local function cargar_lista_spawns()
    local path = archivo_path()
    local f = io.open(path, "r")
    if not f then return end
    local content = f:read("*all")
    f:close()
    local ok, data = pcall(minetest.deserialize, content)
    if ok and type(data) == "table" and type(data.lista) == "table" then
        lista_spawns = data.lista
        spawn_actual_index = tonumber(data.index) or 1
        if spawn_actual_index < 1 then spawn_actual_index = 1 end
    end
end

cargar_lista_spawns()

-- Helper: obtener spawn actual (pos)
local function get_spawn_actual_pos()
    local s = lista_spawns[spawn_actual_index]
    if s and s.pos then return s.pos end
    return config.spawn_global_default
end
M.get_spawn_actual = get_spawn_actual_pos

-- Crear plataforma 3x3x1 en el spawn actual
function M.crear_plataforma_spawn()
    local s = get_spawn_actual_pos()
    local mat = config.spawn_material
    local y = s.y - 1
    for x = s.x - 1, s.x + 1 do
        for z = s.z - 1, s.z + 1 do
            minetest.set_node({ x = x, y = y, z = z }, { name = mat })
        end
    end
    return true, "Plataforma creada en spawn: " .. minetest.pos_to_string(s)
end

-- Genera posiciones centrales y p1/p2 de todas las zonas según separación y spawn actual
function M.generar_posiciones_zonas()
    local spawn = get_spawn_actual_pos()
    local base_y = spawn.y - offset_bajo_spawn
    local sep = M.separacion
    local start_x = spawn.x - ((columnas - 1) * sep) / 2
    local start_z = spawn.z - ((filas - 1) * sep) / 2

    for i = 1, #M.zonas_equipo do
        local r = math.floor((i - 1) / columnas)
        local c = (i - 1) % columnas
        local cx = start_x + c * sep
        local cz = start_z + r * sep
        local centro = { x = cx, y = base_y, z = cz }

        -- calculo de p1/p2 (enteros)
        local base = M.tamano.x
        local alt = M.tamano.y
        -- p1.x = floor(centro.x - (base-1)/2)
        local p1x = math.floor(centro.x - (base - 1) / 2)
        local p1z = math.floor(centro.z - (base - 1) / 2)
        local p1y = centro.y
        local p2x = p1x + base - 1
        local p2z = p1z + base - 1
        local p2y = p1y + alt - 1

        M.zonas_equipo[i].centro = centro
        M.zonas_equipo[i].p1 = { x = p1x, y = p1y, z = p1z }
        M.zonas_equipo[i].p2 = { x = p2x, y = p2y, z = p2z }
    end
    return true, "Posiciones de zonas regeneradas (separacion=" .. tostring(M.separacion) .. ")"
end

-- Ver zonas (string con líneas)
function M.ver_zonas()
    if not M.zonas_equipo or #M.zonas_equipo == 0 then return "No hay zonas definidas." end
    M.generar_posiciones_zonas()
    local out = {}
    for i, z in ipairs(M.zonas_equipo) do
        if z.centro then
            table.insert(out, string.format("%2d -> %s  centro=%s", i, z.nombre or ("zona"..i), minetest.pos_to_string(z.centro)))
        end
    end
    return table.concat(out, "\n")
end

-- Ver lista de spawns (muestra índices empezando por 0)
function M.ver_spawns()
    local lines = {}
    for i, s in ipairs(lista_spawns) do
        local display_index = i - 1
        table.insert(lines, string.format("%d) %s  %s", display_index, s.nombre or ("Spawn "..display_index), minetest.pos_to_string(s.pos)))
    end
    return table.concat(lines, "\n")
end

-- Elegir spawn: recibe display id (0..n). No hace teleport (lo hará el admin desde init).
function M.elegir_spawn(display_id)
    local idn = tonumber(display_id)
    if idn == nil then return false, "ID inválido" end
    local idx = idn + 1
    if not lista_spawns[idx] then return false, "Spawn no encontrado: " .. tostring(display_id) end
    spawn_actual_index = idx
    M.generar_posiciones_zonas()
    guardar_lista_spawns()
    return true, "Spawn elegido: " .. (lista_spawns[idx].nombre or ("Spawn "..display_id))
end

-- Definir spawn (usa la posición del jugador si no recibe coords)
-- agrega a lista_spawns, pone spawn activo en la nueva entrada y crea plataforma
function M.definir_spawn(caller_name, param)
    local player = minetest.get_player_by_name(caller_name)
    if not player then return false, "Jugador no encontrado." end

    local args = {}
    for token in string.gmatch(param or "", "%S+") do table.insert(args, token) end
    local pos
    if #args == 3 then
        pos = { x = tonumber(args[1]), y = tonumber(args[2]), z = tonumber(args[3]) }
        if not pos.x or not pos.y or not pos.z then return false, "Coordenadas inválidas." end
    else
        pos = vector.round(player:get_pos())
    end

    -- nombre display será (current_count) => por ejemplo, si hay 1 spawn existente (default),
    -- el nuevo será display index 1 (lista_spawns length before insert = 1)
    local new_index = #lista_spawns + 1
    local display = new_index - 1
    local name = "Spawn " .. display
    table.insert(lista_spawns, { nombre = name, pos = pos })
    spawn_actual_index = new_index

    -- persistir, regenerar zonas y crear plataforma
    guardar_lista_spawns()
    M.generar_posiciones_zonas()
    M.crear_plataforma_spawn()

    -- teletransportar al admin que definió el spawn
    player:set_pos(pos)

    return true, "Spawn definido y activado: " .. minetest.pos_to_string(pos) .. " (display id " .. tostring(display) .. ")"
end

-- Set / get separacion en runtime
function M.set_separacion(n)
    n = tonumber(n)
    if not n or n <= 0 then return false, "Separacion inválida." end
    M.separacion = n
    M.generar_posiciones_zonas()
    return true, "Separación actualizada a " .. tostring(n)
end
function M.get_separacion() return M.separacion end

-- Crear zona hueca para el índice (usa p1/p2 calculados)
function M.crear_zona_equipo(idx, material_override)
    idx = tonumber(idx)
    if not idx then return false, "Índice inválido." end
    if not M.zonas_equipo[idx] then return false, "Zona "..tostring(idx).." no existe." end
    -- asegurarse de que posiciones están generadas
    M.generar_posiciones_zonas()
    local z = M.zonas_equipo[idx]
    local p1, p2 = z.p1, z.p2
    if not p1 or not p2 then return false, "Coordenadas de zona no definidas." end
    local mat = material_override or z.material or config.zona_material_default or "default:stone"
    -- validar nodo
    if not minetest.registered_nodes[mat] then return false, "Material inválido: "..tostring(mat) end

    for x = p1.x, p2.x do
        for y = p1.y, p2.y do
            for zc = p1.z, p2.z do
                local borde = (x == p1.x or x == p2.x or y == p1.y or y == p2.y or zc == p1.z or zc == p2.z)
                if borde then
                    minetest.set_node({ x = x, y = y, z = zc }, { name = mat })
                else
                    minetest.set_node({ x = x, y = y, z = zc }, { name = "air" })
                end
            end
        end
    end
    return true, "Zona "..idx.." creada con "..mat
end

function M.crear_todas_las_zonas(mat)
    M.generar_posiciones_zonas()
    for i = 1, #M.zonas_equipo do
        local ok, msg = M.crear_zona_equipo(i, mat)
        if not ok then return false, msg end
    end
    return true, "Todas las zonas creadas."
end

-- Limpiar zona
function M.limpiar_zona_equipo(idx)
    idx = tonumber(idx)
    if not idx or not M.zonas_equipo[idx] then return false, "Zona inválida." end
    M.generar_posiciones_zonas()
    local z = M.zonas_equipo[idx]
    local p1, p2 = z.p1, z.p2
    for x = p1.x, p2.x do
        for y = p1.y, p2.y do
            for zc = p1.z, p2.z do
                minetest.set_node({ x = x, y = y, z = zc }, { name = "air" })
            end
        end
    end
    return true, "Zona "..idx.." limpiada."
end

function M.limpiar_todas_las_zonas()
    M.generar_posiciones_zonas()
    for i = 1, #M.zonas_equipo do
        M.limpiar_zona_equipo(i)
    end
    return true, "Todas las zonas limpiadas."
end

-- Tamaño zona (base, altura)
function M.set_tamano(base, altura)
    base = tonumber(base)
    altura = tonumber(altura)
    if not base or not altura then return false, "Parámetros inválidos." end
    -- validar min/max desde config
    local b = math.max(config.zona_base_min, math.min(base, config.zona_base_max))
    local a = math.max(config.zona_altura_min, math.min(altura, config.zona_altura_max))
    M.tamano = { x = b, y = a, z = b }
    M.generar_posiciones_zonas()
    return true, "Tamaño aplicado: base="..b.." altura="..a
end

function M.get_tamano() return M.tamano end

-- Inicializar posiciones al cargar módulo
M.generar_posiciones_zonas = M.generar_posiciones_zonas
M.crear_plataforma_spawn() -- crear plataforma en el spawn activo al iniciar el mod

-- export
M.ver_spawns = M.ver_spawns
M.elegir_spawn = M.elegir_spawn
M.definir_spawn = M.definir_spawn
M.set_separacion = M.set_separacion
M.get_separacion = M.get_separacion
M.crear_zona_equipo = M.crear_zona_equipo
M.crear_todas_las_zonas = M.crear_todas_las_zonas
M.limpiar_zona_equipo = M.limpiar_zona_equipo
M.limpiar_todas_las_zonas = M.limpiar_todas_las_zonas
M.ver_zonas = M.ver_zonas
M.get_spawn_list = function() return lista_spawns end
M.get_spawn_index = function() return spawn_actual_index end

return M
