-- init.lua - Sistema de equipos (versión corregida)
-- Cambios: bloqueo de cambio de skin para estudiantes; admins no se teletransportan en reset.

local modname = "equipos"
local modpath = minetest.get_modpath(modname)
local config = dofile(modpath .. "/config.lua")
local zonas = dofile(modpath .. "/zonas.lua")

-- asignaciones: jugador -> nombre_equipo
local asignaciones = {}
math.randomseed(os.time())

-- skin defaults desde config (fallbacks)
local skin_default_entrada = config.skin_default_entrada or "character_1"
local skin_default_partida = config.skin_default_partida or "character_2"

-- ============================
-- UTILIDADES
-- ============================
local function es_administrador(name)
    for _, a in ipairs(config.administradores) do if a == name then return true end end
    return false
end

local function permitido(name)
    for _, u in ipairs(config.usuarios_permitidos) do if u == name then return true end end
    return false
end

local function send_multiline(player_name, text)
    if not text then return end
    for line in string.gmatch(text, "[^\n]+") do
        minetest.chat_send_player(player_name, line)
    end
end

-- Seguro al actualizar skin (usa el mod simple_skins si existe)
local function safe_update_skin(player_name, skin_id)
    if not player_name or not skin_id then return end
    if rawget(_G, "skins") and type(skins.update_player_skin) == "function" then
        skins.skins[player_name] = skin_id
        local p = minetest.get_player_by_name(player_name)
        if p then
            p:get_meta():set_string("simple_skins:skin", skin_id)
            skins.update_player_skin(p)
        end
    else
        -- si no existe simple_skins, no hacemos nada
    end
end

-- ============================
-- BLOQUEO CAMBIO DE SKIN (para estudiantes)
-- ============================
-- Si el mod simple_skins está presente, interceptamos la función event_CHG
if rawget(_G, "skins") then
    local old_event = skins.event_CHG
    skins.event_CHG = function(event, player)
        if not player then
            if old_event then return old_event(event, player) end
            return
        end
        local name = player:get_player_name()
        -- Admins pueden cambiar skin normalmente: delegamos al handler original (si existe)
        if es_administrador(name) then
            if old_event then return old_event(event, player) end
            return
        end

        -- Estudiante: forzar skin asignado al equipo si existe, sino skin_default_entrada
        local forced_skin = skin_default_entrada or "character_1"

        -- si el jugador ya tiene asignado un equipo en 'asignaciones', buscamos su skin
        if asignaciones[name] then
            local equipo_nombre = asignaciones[name]
            -- buscar la zona cuyo nombre coincida con el nombre del equipo
            for i, z in ipairs(zonas.zonas_equipo or {}) do
                if z.nombre == equipo_nombre and z.skin then
                    forced_skin = z.skin
                    break
                end
            end
        end

        -- aplicar skin forzada
        skins.skins[name] = forced_skin
        player:get_meta():set_string("simple_skins:skin", forced_skin)
        skins.update_player_skin(player)

        minetest.chat_send_player(name, "⚠ No puedes cambiar tu skin. Tu equipo tiene el skin: " .. forced_skin)
        return
    end
end

-- ============================
-- EVENTOS DE CONEXIÓN
-- ============================
minetest.register_on_prejoinplayer(function(name)
    if not permitido(name) then
        return "⛔ Usuario no autorizado para ingresar al servidor."
    end
end)

minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    -- Teletransportar a spawn actual y asegurar plataforma
    local spawn = zonas.get_spawn_actual()
    if spawn then
        player:set_pos(spawn)
        zonas.crear_plataforma_spawn()
    end

    if es_administrador(name) then
        minetest.set_player_privs(name, minetest.registered_privileges)
        minetest.chat_send_player(name, "👑 Bienvenido administrador.")
    else
        minetest.set_player_privs(name, { shout = true, interact = true })
        -- Aplicar skin por defecto de entrada
        safe_update_skin(name, skin_default_entrada)
        minetest.chat_send_player(name, "Bienvenido. Esperando inicio de partida...")
    end
end)

-- ============================
-- REQUISITOS DE ADMIN
-- ============================
local function require_admin(name)
    if not es_administrador(name) then
        return false, "❌ Solo los administradores pueden ejecutar este comando."
    end
    return true
end

-- ============================
-- COMANDOS: PARTIDA
-- ============================
minetest.register_chatcommand("iniciar_partida", {
    params = "<tamaño_equipo>",
    description = "Inicia la partida y reparte estudiantes en equipos de 3 o 5",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end

        local tam = tonumber(param)
        if tam ~= 3 and tam ~= 5 then
            return false, "Uso: /iniciar_partida 3  o  /iniciar_partida 5"
        end

        -- regenerar posiciones y validar
        zonas.generar_posiciones_zonas()
        local zonas_tab = zonas.zonas_equipo
        if not zonas_tab or #zonas_tab == 0 then return false, "No hay zonas definidas." end

        local estudiantes = {}
        for _, p in ipairs(minetest.get_connected_players()) do
            local pn = p:get_player_name()
            if not es_administrador(pn) then table.insert(estudiantes, pn) end
        end
        if #estudiantes == 0 then return false, "No hay estudiantes conectados." end

        -- asignar skin default de partida antes de repartir (opcional)
        for _, pn in ipairs(estudiantes) do safe_update_skin(pn, skin_default_partida) end

        -- mezclar alumnos
        for i = #estudiantes, 2, -1 do
            local j = math.random(i)
            estudiantes[i], estudiantes[j] = estudiantes[j], estudiantes[i]
        end

        asignaciones = {}
        local grupo = 1
        local idx = 1
        while idx <= #estudiantes do
            for k = 1, tam do
                if estudiantes[idx] then
                    local pname = estudiantes[idx]
                    local player = minetest.get_player_by_name(pname)
                    if player then
                        local zona_idx = ((grupo - 1) % #zonas_tab) + 1
                        local zona = zonas_tab[zona_idx]
                        if not zona.centro then zonas.generar_posiciones_zonas(); zona = zonas_tab[zona_idx] end

                        asignaciones[pname] = zona.nombre or ("Equipo" .. zona_idx)

                        local t = zonas.get_tamano()
                        local techo_y = (zona.p2 and zona.p2.y) or (zona.centro.y + t.y - 1)
                        player:set_pos({ x = zona.centro.x, y = techo_y + 1, z = zona.centro.z })

                        -- asignar skin de equipo
                        local skin = zona.skin or skin_default_partida
                        safe_update_skin(pname, skin)

                        minetest.chat_send_player(pname, "🎯 Asignado a " .. asignaciones[pname] .. " | Zona " .. zona_idx)
                    end
                    idx = idx + 1
                end
            end
            grupo = grupo + 1
        end

        return true, "✅ Partida iniciada: " .. #estudiantes .. " estudiantes repartidos."
    end
})

minetest.register_chatcommand("reset_partida", {
    description = "Resetea la partida: devuelve estudiantes al spawn y restaura skin por defecto (admins no se mueven).",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end

        local spawn = zonas.get_spawn_actual()
        for _, p in ipairs(minetest.get_connected_players()) do
            local pn = p:get_player_name()
            if not es_administrador(pn) then
                -- estudiantes vuelven al spawn
                if spawn then p:set_pos(spawn) end
                -- restablecer skin por defecto de entrada
                safe_update_skin(pn, skin_default_entrada)
                -- privs mínimos
                minetest.set_player_privs(pn, { shout = true, interact = true })
            else
                -- administradores mantienen su posición y privilegios completos
                minetest.set_player_privs(pn, minetest.registered_privileges)
            end
        end
        asignaciones = {}
        return true, "🔁 Partida reseteada. Skins de estudiantes restaurados a " .. skin_default_entrada
    end
})

-- ============================
-- COMANDOS: ZONAS
-- ============================
minetest.register_chatcommand("crear_zona", {
    params = "<número> [material]",
    description = "Crea la zona n con material opcional.",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local idx, mat = param:match("^(%S+)%s*(%S*)$")
        if not idx then return false, "Uso: /crear_zona <n> [material]" end
        if mat == "" then mat = nil end
        local success, msg = zonas.crear_zona_equipo(idx, mat)
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("crear_zonas", {
    params = "[material]",
    description = "Crea todas las zonas (material opcional).",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local mat = (param and param ~= "") and param or nil
        local success, msg = zonas.crear_todas_las_zonas(mat)
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("limpiar_zona", {
    params = "<número>",
    description = "Limpia la zona n (reemplaza por air).",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local idx = tonumber(param)
        if not idx then return false, "Uso: /limpiar_zona <número>" end
        local success, msg = zonas.limpiar_zona_equipo(idx)
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("limpiar_zonas", {
    description = "Limpia todas las zonas.",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local success, msg = zonas.limpiar_todas_las_zonas()
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("generar_zonas", {
    description = "Regenera posiciones de zonas (no crea bloques).",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local success, msg = zonas.generar_posiciones_zonas()
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("ver_zonas", {
    description = "Muestra coordenadas de zonas (centros).",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local txt = zonas.ver_zonas()
        send_multiline(name, txt)
        return true, "Listado de zonas enviado."
    end
})

minetest.register_chatcommand("separacion_zonas", {
    params = "<valor>",
    description = "Cambia separación entre centros de zonas (dinámico).",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local n = tonumber(param)
        if not n or n <= 0 then return false, "Uso: /separacion_zonas <valor_positivo>" end
        local success, msg = zonas.set_separacion(n)
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("tp_zona", {
    params = "<n>",
    description = "Teletransporta al admin al centro de la zona n.",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local n = tonumber(param)
        if not n then return false, "Uso: /tp_zona <número>" end
        local zonas_tab = zonas.zonas_equipo
        if not zonas_tab or not zonas_tab[n] or not zonas_tab[n].centro then
            zonas.generar_posiciones_zonas()
            if not zonas_tab[n] or not zonas_tab[n].centro then return false, "Zona no encontrada." end
        end
        local z = zonas_tab[n]
        local p = minetest.get_player_by_name(name)
        if not p then return false, "Jugador no encontrado." end
        local techo_y = (z.p2 and z.p2.y) or (z.centro.y + zonas.get_tamano().y - 1)
        p:set_pos({ x = z.centro.x, y = techo_y + 1, z = z.centro.z })
        return true, "Teletransportado a zona " .. n
    end
})

-- ============================
-- COMANDOS: TAMAÑO
-- ============================
minetest.register_chatcommand("tamano_zona", {
    params = "<base> <altura>",
    description = "Define base (ancho=largo) y altura de las zonas.",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local base, altura = param:match("^(%S+)%s+(%S+)")
        base = tonumber(base); altura = tonumber(altura)
        if not base or not altura then return false, "Uso: /tamano_zona <base> <altura>" end
        local success, msg = zonas.set_tamano(base, altura)
        if success then return true, msg else return false, msg end
    end
})

minetest.register_chatcommand("ver_tamano_zona", {
    description = "Muestra tamaño actual de las zonas.",
    privs = { server = true },
    func = function(name)
        local t = zonas.get_tamano()
        if not t then return false, "Tamaño no definido." end
        return true, string.format("Tamaño actual: base=%d altura=%d", t.x, t.y)
    end
})

-- ============================
-- COMANDOS: SPAWN
-- ============================
minetest.register_chatcommand("definir_spawn", {
    params = "[x y z]",
    description = "Define un nuevo spawn (si no pasas coords usa tu posición).",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local success, msg = zonas.definir_spawn(name, param)
        if not success then return false, msg end
        -- la función zonas.definir_spawn ya crea plataforma y teletransporta al admin
        return true, msg
    end
})

minetest.register_chatcommand("ver_spawn", {
    description = "Muestra el spawn activo.",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local s = zonas.get_spawn_actual()
        return true, "Spawn actual: " .. minetest.pos_to_string(s)
    end
})

minetest.register_chatcommand("ver_spawns", {
    description = "Lista todos los spawns registrados (id empieza en 0).",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local txt = zonas.ver_spawns()
        send_multiline(name, txt)
        return true, "Spawns listados por chat."
    end
})

minetest.register_chatcommand("elegir_spawn", {
    params = "<id>",
    description = "Activa el spawn con id (id mostrado por /ver_spawns; id 0 = default).",
    privs = { server = true },
    func = function(name, param)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        if not param or param == "" then return false, "Uso: /elegir_spawn <id> (id empieza en 0)" end
        local success, msg = zonas.elegir_spawn(param)
        if not success then return false, msg end
        zonas.crear_plataforma_spawn()
        local player = minetest.get_player_by_name(name)
        if player then player:set_pos(zonas.get_spawn_actual()) end
        return true, msg .. " (teletransportado)"
    end
})
----------------------------------------------------------
-- 🕓 Comando: /pausar <jugador> [minutos]
-- 🕊️ Comando: /liberar <jugador>
-- Sistema de pausa temporal para estudiantes
-- (solo administradores)
----------------------------------------------------------

local pausados = pausados or {}

-- 🔒 PAUSAR JUGADOR
minetest.register_chatcommand("pausar", {
    params = "<nombre> [minutos]",
    description = "Pausa temporalmente a un estudiante y lo envía al spawn.",
    privs = {server = true},
    func = function(name, param)
        local args = param:split(" ")
        local objetivo = args[1]
        local minutos = tonumber(args[2]) or 2

        if not objetivo then
            return false, "Uso: /pausar <nombre_estudiante> [minutos]"
        end

        if not es_administrador(name) then
            return false, "Solo los administradores pueden usar este comando."
        end

        local player = minetest.get_player_by_name(objetivo)
        if not player then
            return false, "⚠ El jugador '" .. objetivo .. "' no está conectado."
        end

        if pausados[objetivo] then
            return false, "⚠ El jugador '" .. objetivo .. "' ya está pausado."
        end

        -- Guardar posición original
        local pos_original = player:get_pos()

        -- Enviar al spawn actual
        local spawn = zonas.get_spawn_global and zonas.get_spawn_global() or {x=0, y=50, z=0}
        player:set_pos(spawn)

        -- Quitar movimiento e interacción
        player:set_physics_override({speed=0, jump=0, gravity=1})
        minetest.set_player_privs(objetivo, {shout=true}) -- solo puede hablar

        pausados[objetivo] = {
            pos_original = pos_original,
            tiempo = minutos * 60,
            inicio = os.time(),
        }

        minetest.chat_send_all("⏸️ El jugador " .. objetivo .. " fue pausado por " .. minutos .. " minuto(s).")

        -- Restaurar automáticamente
        minetest.after(minutos * 60, function()
            if pausados[objetivo] then
                local p = minetest.get_player_by_name(objetivo)
                if p then
                    p:set_pos(pausados[objetivo].pos_original)
                    p:set_physics_override({speed=1, jump=1, gravity=1})
                    minetest.set_player_privs(objetivo, {interact=true, shout=true})
                    minetest.chat_send_all("▶️ El jugador " .. objetivo .. " ha vuelto al juego.")
                end
                pausados[objetivo] = nil
            end
        end)

        return true, "✅ " .. objetivo .. " fue pausado por " .. minutos .. " minuto(s)."
    end,
})

-- 🔓 LIBERAR JUGADOR ANTES DE TIEMPO
minetest.register_chatcommand("liberar", {
    params = "<nombre>",
    description = "Libera a un jugador pausado antes de que termine su tiempo.",
    privs = {server = true},
    func = function(name, param)
        local objetivo = param:trim()
        if objetivo == "" then
            return false, "Uso: /liberar <nombre_estudiante>"
        end

        if not es_administrador(name) then
            return false, "Solo los administradores pueden usar este comando."
        end

        local data = pausados[objetivo]
        if not data then
            return false, "⚠ El jugador '" .. objetivo .. "' no está pausado."
        end

        local p = minetest.get_player_by_name(objetivo)
        if p then
            p:set_pos(data.pos_original)
            p:set_physics_override({speed=1, jump=1, gravity=1})
            minetest.set_player_privs(objetivo, {interact=true, shout=true})
        end
        pausados[objetivo] = nil

        minetest.chat_send_all("🕊️ El jugador " .. objetivo .. " fue liberado por " .. name .. ".")
        return true, "Jugador liberado correctamente."
    end,
})

-- 🔁 Si un jugador pausado se reconecta, se mantiene la pausa
minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    if pausados[name] then
        local restante = pausados[name].tiempo - (os.time() - pausados[name].inicio)
        if restante > 0 then
            player:set_physics_override({speed=0, jump=0, gravity=1})
            player:set_pos(zonas.get_spawn_global())
            minetest.chat_send_player(name, "⏸️ Sigues en pausa. Espera " .. math.ceil(restante / 60) .. " min para volver.")
            minetest.after(restante, function()
                if pausados[name] then
                    local p = minetest.get_player_by_name(name)
                    if p then
                        p:set_pos(pausados[name].pos_original)
                        p:set_physics_override({speed=1, jump=1, gravity=1})
                        minetest.set_player_privs(name, {interact=true, shout=true})
                        minetest.chat_send_all("▶️ " .. name .. " ha vuelto al juego.")
                    end
                    pausados[name] = nil
                end
            end)
        end
    end
end)
-- 📋 LISTAR JUGADORES PAUSADOS
minetest.register_chatcommand("pausados", {
    description = "Muestra la lista de jugadores pausados y el tiempo restante.",
    privs = {server = true},
    func = function(name)
        if not next(pausados) then
            return true, "No hay jugadores pausados actualmente."
        end

        minetest.chat_send_player(name, "⏸️ Jugadores pausados:")
        for jugador, data in pairs(pausados) do
            local restante = math.max(0, data.tiempo - (os.time() - data.inicio))
            local min_restante = math.ceil(restante / 60)
            minetest.chat_send_player(name, "- " .. jugador .. " (" .. min_restante .. " min restantes)")
        end
        return true
    end,
})
----------------------------------------------------------
-- 🎒 LIMITADOR DE INVENTARIO (Versión mejorada y segura)
-- Evita acumulaciones excesivas y deja caer los excesos
-- Los administradores están excluidos del control
----------------------------------------------------------

local max_bloques = config.max_bloques or 10
local herramientas = {"pick", "shovel", "axe", "sword", "hoe", "hammer"}

-- Determinar si un ítem es una herramienta
local function es_herramienta(name)
    for _, tipo in ipairs(herramientas) do
        if name:find(tipo) then
            return true
        end
    end
    return false
end

-- Soltar exceso en el suelo en lugar de eliminarlo
local function soltar_exceso(player, item_name, cantidad)
    if cantidad <= 0 then return end
    local pos = player:get_pos()
    if not pos then return end
    pos.y = pos.y + 1.5
    local itemstack = ItemStack(item_name .. " " .. cantidad)
    minetest.add_item(pos, itemstack)
end

-- Función para saber si un jugador es administrador
local function es_administrador(name)
    local administradores = {"creador", "profe_daniel", "admin"} -- también puedes leerlo desde config.lua si lo deseas
    for _, adm in ipairs(administradores) do
        if adm == name then
            return true
        end
    end
    return false
end

-- Verificar inventario y aplicar límites
local function verificar_inventario(player)
    if not player or not player:is_player() then return end
    local name = player:get_player_name()
    if es_administrador(name) then return end  -- 🔒 los admins no tienen límites

    local inv = player:get_inventory()
    if not inv then return end

    local main = inv:get_list("main")
    if not main then return end

    local conteo = {}
    for i, stack in ipairs(main) do
        if not stack:is_empty() then
            local item_name = stack:get_name()
            local cantidad = stack:get_count()
            conteo[item_name] = (conteo[item_name] or 0) + cantidad

            -- 🔧 Limitar bloques
            if not es_herramienta(item_name) and conteo[item_name] > max_bloques then
                local exceso = conteo[item_name] - max_bloques
                stack:set_count(stack:get_count() - exceso)
                inv:set_stack("main", i, stack)
                soltar_exceso(player, item_name, exceso)
                minetest.chat_send_player(name,
                    "⚠ Solo puedes tener " .. max_bloques .. " unidades de '" .. item_name .. "'. Exceso devuelto al suelo.")
            end

            -- 🔨 Limitar herramientas
            if es_herramienta(item_name) and conteo[item_name] > 1 then
                local exceso = conteo[item_name] - 1
                stack:set_count(stack:get_count() - exceso)
                inv:set_stack("main", i, stack)
                soltar_exceso(player, item_name, exceso)
                minetest.chat_send_player(name,
                    "⚠ Solo puedes tener una herramienta de tipo '" .. item_name .. "'. Exceso devuelto al suelo.")
            end
        end
    end
end

----------------------------------------------------------
-- 🚧 Eventos que activan el control (versión corregida)
----------------------------------------------------------

minetest.register_on_player_inventory_action(function(player)
    if player and player:is_player() then
        verificar_inventario(player)
    end
end)

-- 🧱 Al recoger un ítem
minetest.register_on_item_pickup(function(player, itemstack)
    -- A veces este evento se dispara con player = nil o una entidad no válida
    if not player or type(player) ~= "userdata" then
        return
    end
    local ok, valid = pcall(function() return player:is_player() end)
    if not ok or not valid then
        return
    end
    minetest.after(0.1, function()
        if player and player:is_player() then
            verificar_inventario(player)
        end
    end)
end)

-- 🔁 También al reconectarse
minetest.register_on_joinplayer(function(player)
    minetest.after(2, function()
        if player and player:is_player() then
            verificar_inventario(player)
        end
    end)
end)

----------------------------------------------------------
-- ⚙️ COMANDO ADMIN: cambiar límite de bloques
----------------------------------------------------------
----------------------------------------------------------
-- 🧠 Comando para cambiar límite dinámicamente y guardar en config.lua
----------------------------------------------------------
minetest.register_chatcommand("limite_bloques", {
    params = "<valor>",
    description = "Cambia el número máximo de bloques iguales que puede tener un jugador (default: 10). Guarda el cambio en config.lua.",
    privs = {server = true},
    func = function(name, param)
        local nuevo = tonumber(param)
        if not nuevo or nuevo < 1 then
            return false, "Uso: /limite_bloques <número_máximo>"
        end

        max_bloques = nuevo
        config.max_bloques = nuevo

        -- Ruta al archivo config.lua del mod
        local modpath = minetest.get_modpath("equipos")
        local config_path = modpath .. "/config.lua"

        -- Leer contenido actual del archivo
        local file = io.open(config_path, "r")
        local contenido = file and file:read("*all") or ""
        if file then file:close() end

        -- Buscar la línea existente de max_bloques y reemplazarla
        local nuevo_contenido
        if contenido:find("config%.max_bloques%s*=") then
            nuevo_contenido = contenido:gsub("config%.max_bloques%s*=%s*%d+", "config.max_bloques = " .. nuevo)
        else
            -- Si no existe la línea, la agregamos al final del archivo
            nuevo_contenido = contenido .. "\nconfig.max_bloques = " .. nuevo .. "\n"
        end

        -- Guardar el nuevo archivo
        local out = io.open(config_path, "w")
        if out then
            out:write(nuevo_contenido)
            out:close()
            minetest.chat_send_all("⚙️ Límite de bloques actualizado a " .. nuevo .. " por " .. name .. " (guardado en config.lua).")
            return true
        else
            return false, "❌ No se pudo escribir en config.lua (verifica permisos de escritura)."
        end
    end,
})


-- ============================
-- COMANDOS: USUARIOS Y AYUDA
-- ============================
minetest.register_chatcommand("usuarios", {
    description = "Lista usuarios activos y no activos (permitidos en config).",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        local activos, inactivos = {}, {}
        for _, u in ipairs(config.usuarios_permitidos) do
            if minetest.get_player_by_name(u) then table.insert(activos, u) else table.insert(inactivos, u) end
        end
        minetest.chat_send_player(name, "🟢 Activos: " .. (next(activos) and table.concat(activos, ", ") or "ninguno"))
        minetest.chat_send_player(name, "⚫ Inactivos: " .. (next(inactivos) and table.concat(inactivos, ", ") or "ninguno"))
        return true, "Usuarios listados."
    end
})

minetest.register_chatcommand("usuarios_permitidos", {
    description = "Lista usuarios permitidos desde config.lua",
    privs = { server = true },
    func = function(name)
        local ok, err = require_admin(name)
        if not ok then return false, err end
        send_multiline(name, "Usuarios permitidos: " .. table.concat(config.usuarios_permitidos, ", "))
        return true, "Usuarios permitidos enviados."
    end
})

-- ======================================================
-- 📜 AYUDA DEL MOD "equipos"
-- ======================================================
minetest.register_chatcommand("ayuda", {
    description = "Muestra todos los comandos disponibles del mod 'equipos'.",
    func = function(name)
        local ayuda = [[
📘 COMANDOS DEL MOD "equipos"

🧑‍🏫 Administración (solo admins)
  /iniciar_partida <3|5>
  /reset_partida

🧱 Zonas (admins)
  /crear_zona <n> [mat]
  /crear_zonas [mat]
  /limpiar_zona <n>
  /limpiar_zonas
  /generar_zonas
  /ver_zonas
  /separacion_zonas <valor>
  /tp_zona <n>

📐 Tamaño (admins)
  /tamano_zona <base> <altura>
  /ver_tamano_zona

🚀 Spawn (admins)
  /definir_spawn [x y z]
  /ver_spawn
  /ver_spawns
  /elegir_spawn <id>

👥 Usuarios (admins)
  /usuarios
  /usuarios_permitidos
  /pausar <nombre> [minutos]
  /liberar <nombre>
  /pausados
  /limite_bloques [n]

🧾 General
  /ayuda
]]
        minetest.chat_send_player(name, ayuda)
        return true
    end,
})


-- ============================
-- INICIALIZACIÓN
-- ============================
minetest.after(1, function()
    -- asegurar plataforma spawn y posiciones de zonas al arrancar
    pcall(function() zonas.crear_plataforma_spawn() end)
    pcall(function() zonas.generar_posiciones_zonas() end)
end)

-- Fin de init.lua
