-- =========================================
-- SISTEMA DE REAPARICIÓN (RESPAWN)
-- =========================================

local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")
local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local zonas = dofile(minetest.get_modpath("equipos") .. "/sistemas/zonas.lua")

local respawn = {
    modo = config.modo_respawn or "global" -- "global", "castigo" o "muerte"
}

-- ⚙️ Cambiar modo de respawn
minetest.register_chatcommand("modo_respawn", {
    params = "<global|castigo|muerte>",
    description = "Define el modo de reaparecer de los jugadores.",
    privs = {server=true},
    func = function(name, param)
        if param ~= "global" and param ~= "castigo" and param ~= "muerte" then
            return false, "Usa: /modo_respawn global|castigo|muerte"
        end
        respawn.modo = param
        config.modo_respawn = param
        persist.guardar_config(config)
        persist.registrar_evento("RESPAWN", name, "Modo de respawn cambiado a " .. param)
        return true, "✅ Modo de respawn establecido en: " .. param
    end
})

-- ⚰️ Al morir
minetest.register_on_dieplayer(function(player)
    local name = player:get_player_name()
    local pos_muerte = player:get_pos()

    minetest.after(1, function()
        local destino = zonas.spawn_global

        if respawn.modo == "castigo" and config.spawn_castigo then
            destino = config.spawn_castigo
        elseif respawn.modo == "muerte" then
            destino = pos_muerte
        end

        if destino then
            zonas.crear_base_spawn(destino)
            player:set_pos(destino)
            persist.registrar_evento("RESPAWN", name, "Reapareció en " .. util.str_pos(destino))
        end
    end)
end)

return respawn
