-- =========================================
-- SISTEMA DE LÍMITE DE ÍTEMS
-- =========================================

local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")
local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")

local inventario = {}
local max_bloques = config.max_bloques or 10

-- 🔧 Cambiar límite
minetest.register_chatcommand("limite_bloques", {
    params = "<número>",
    description = "Cambia el límite de bloques permitidos en inventario.",
    privs = {server=true},
    func = function(name, param)
        local n = tonumber(param)
        if not n or n < 1 then return false, "Debe ser un número válido" end
        max_bloques = n
        config.max_bloques = n
        persist.guardar_config(config)
        return true, "✅ Límite de bloques actualizado a " .. n
    end
})

-- 🧱 Verificar inventario (cada 2 seg)
local function verificar_inventario()
    for _, player in ipairs(minetest.get_connected_players()) do
        local name = player:get_player_name()
        if util.es_administrador(name) then goto continue end
        local inv = player:get_inventory()
        if not inv then goto continue end
        for i = 1, inv:get_size("main") do
            local stack = inv:get_stack("main", i)
            if not stack:is_empty() then
                local count = stack:get_count()
                if count > max_bloques then
                    stack:set_count(max_bloques)
                    inv:set_stack("main", i, stack)
                    minetest.chat_send_player(name, "⚠ Límite de " .. max_bloques .. " items alcanzado.")
                    persist.registrar_evento("INVENTARIO", name, "Se ajustó exceso de " .. stack:get_name())
                end
            end
        end
        ::continue::
    end
end

local acumulador = 0
minetest.register_globalstep(function(dtime)
    acumulador = acumulador + dtime
    if acumulador >= 2 then
        verificar_inventario()
        acumulador = 0
    end
end)

return inventario
