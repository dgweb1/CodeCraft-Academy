-- sistemas/usuarios.lua
-- Gestión de usuarios: privilegios, lista blanca y comandos relacionados

local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")
local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")

local usuarios = {}

-- Devuelve true si es admin (usa config)
local function es_admin(name)
    for _, adm in ipairs(config.administradores or {}) do
        if adm == name then return true end
    end
    return false
end

-- Al entrar: admins con todos los privilegios; estudiantes al spawn_default con privilegios limitados
minetest.register_on_joinplayer(function(player)
    if not player then return end
    local name = player:get_player_name()
    if es_admin(name) then
        -- Dar TODOS los privilegios registrados al admin
        if minetest.registered_privileges then
            minetest.set_player_privs(name, minetest.registered_privileges)
        else
            -- fallback: permisos comunes
            minetest.set_player_privs(name, {
                shout=true, interact=true, fly=true, fast=true, noclip=true,
                give=true, kick=true, ban=true, teleport=true, privs=true,
                settime=true, setpassword=true, protection_bypass=true,
                rollback=true, bring=true, password=true, server=true,
                worldedit=true, areas=true
            })
        end
        minetest.chat_send_player(name, "✅ Bienvenido Administrador. Tienes todos los privilegios.")
        return
    end

    -- comprobación lista blanca
    local permitido = false
    for _, u in ipairs(config.usuarios_permitidos or {}) do
        if u == name then permitido = true; break end
    end
    if not permitido then
        -- Denegar ingreso: returning string here will block join (minetest handles this on_prejoinplayer)
        -- Pero como ya está dentro on_joinplayer, sólo avisamos y/o kickeamos:
        minetest.kick_player(name, "No estás autorizado en este servidor.")
        return
    end

    -- Teletransportar estudiante al spawn global por defecto (config.spawn_global)
    local spawn_pos = config.spawn_global or {x=0,y=50,z=0}
    if spawn_pos and spawn_pos.x then
        -- crear base sólida bajo el spawn si es necesario (usa util)
        util.crear_base_solida(spawn_pos)
        player:set_pos({x = spawn_pos.x, y = spawn_pos.y + 1, z = spawn_pos.z})
    end

    -- Privilegios mínimos para estudiantes
    minetest.set_player_privs(name, {
        shout = true,
        interact = true,
    })
    minetest.chat_send_player(name, "Bienvenido. Esperando inicio de la partida.")
end)

-- Comando para mostrar usuarios conectados
minetest.register_chatcommand("usuarios", {
    description = "Muestra los jugadores conectados.",
    privs = {server=true},
    func = function(name)
        local connected = {}
        for _, p in ipairs(minetest.get_connected_players()) do
            table.insert(connected, p:get_player_name())
        end
        minetest.chat_send_player(name, "Conectados: " .. (table.concat(connected, ", ") or "ninguno"))
        return true
    end
})

-- Comando para ver lista blanca (usuarios_permitidos)
minetest.register_chatcommand("usuarios_permitidos", {
    description = "Muestra la lista blanca de acceso.",
    privs = {server=true},
    func = function(name)
        minetest.chat_send_player(name, "Usuarios permitidos: " .. table.concat(config.usuarios_permitidos, ", "))
        return true
    end
})

return usuarios
