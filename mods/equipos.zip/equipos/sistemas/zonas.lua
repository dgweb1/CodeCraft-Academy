-- =========================================
-- SISTEMA DE ZONAS Y SPAWNS
-- =========================================

local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")
local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")

local zonas = {
    lista = {},
    spawn_global = config.spawn_global,
    spawn_castigo = config.spawn_castigo
}

-- 🧱 Crear una zona cuadrada hueca
local function crear_area(pos_centro, ancho, alto, material)
    local mitad = math.floor(ancho / 2)
    for x = -mitad, mitad do
        for z = -mitad, mitad do
            for y = 0, alto - 1 do
                local pos = {
                    x = pos_centro.x + x,
                    y = pos_centro.y + y,
                    z = pos_centro.z + z
                }
                if y == 0 or y == alto - 1 or x == -mitad or x == mitad or z == -mitad or z == mitad then
                    minetest.set_node(pos, {name = material})
                else
                    minetest.remove_node(pos)
                end
            end
        end
    end
end

-- 🧭 Crear todas las zonas en grilla
function zonas.generar_zonas(material_override)
    zonas.lista = {}
    local zonas_equipo = config.zonas_equipo or {}
    local ancho = config.zona.ancho
    local alto = config.zona.alto
    local sep = config.zona.separacion

    -- punto base de la grilla (centro de zona 1)
    local base_x = config.spawn_global.x + 50  -- desplazado a la derecha del spawn
    local base_z = config.spawn_global.z
    local base_y = config.spawn_global.y - 50  -- 50 bloques debajo del spawn

    local columnas = 5
    local filas = 3

    for i = 1, 15 do
        local fila = math.floor((i - 1) / columnas)
        local columna = (i - 1) % columnas

        local cx = base_x + (columna * (ancho + sep))
        local cz = base_z + (fila * (ancho + sep))
        local cy = base_y

        local zconf = zonas_equipo[i] or {}
        local centro = {x = cx, y = cy, z = cz}
        local material = material_override or zconf.material or config.zona.material_default
        local skin = zconf.skin or "character_" .. i
        local nombre = zconf.nombre or "Equipo " .. i

        table.insert(zonas.lista, {
            nombre = nombre,
            centro = centro,
            material = material,
            skin = skin
        })

        crear_area(centro, ancho, alto, material)
    end
end

-- 🧱 Crear una zona específica
function zonas.crear_zona(id, material)
    local z = zonas.lista[id]
    if not z then return false, "Zona no existente" end
    crear_area(z.centro, config.zona.ancho, config.zona.alto, material or config.zona.material_default)
    return true, "Zona " .. id .. " creada."
end

-- 🧹 Limpiar zona
function zonas.limpiar_zona(id)
    local z = zonas.lista[id]
    if not z then return false, "Zona no existente" end
    local mitad = math.floor(config.zona.ancho / 2)
    for x = -mitad, mitad do
        for z2 = -mitad, mitad do
            for y = 0, config.zona.alto - 1 do
                minetest.remove_node({
                    x = z.centro.x + x,
                    y = z.centro.y + y,
                    z = z.centro.z + z2
                })
            end
        end
    end
    return true, "Zona " .. id .. " limpiada."
end

-- 🧱 Crear plataforma segura en el spawn
function zonas.crear_base_spawn(pos)
    for x = -1, 1 do
        for z = -1, 1 do
            minetest.set_node({x = pos.x + x, y = pos.y - 1, z = pos.z + z}, {name = "default:stone"})
        end
    end
end

-- 🚀 Definir spawn
function zonas.definir_spawn(pos)
    zonas.spawn_global = pos
    zonas.crear_base_spawn(pos)
    persist.registrar_evento("SPAWN", "-", "Nuevo spawn definido en " .. util.str_pos(pos))
end

function zonas.get_spawn_global()
    return zonas.spawn_global
end
-- Comando: /crear_zona <id> [material]
minetest.register_chatcommand("crear_zona", {
    params = "<id> [material]",
    description = "Crea la plataforma de una zona específica.",
    privs = {server=true},
    func = function(name, param)
        local id, mat = string.match(param, "^(%d+)%s*(.*)$")
        id = tonumber(id)
        if not id then return false, "Uso: /crear_zona <id> [material]" end
        local ok, msg = zonas.crear_zona(id, mat ~= "" and mat or nil)
        return ok, msg
    end
})

-- Comando: /crear_zonas [material]
minetest.register_chatcommand("crear_zonas", {
    params = "[material]",
    description = "Crea todas las zonas con el material indicado.",
    privs = {server=true},
    func = function(name, param)
        zonas.generar_zonas()
        return true, "✅ Todas las zonas fueron generadas con material: " .. (param ~= "" and param or config.zona.material_default)
    end
})

-- Comando: /limpiar_zona <id>
minetest.register_chatcommand("limpiar_zona", {
    params = "<id>",
    description = "Limpia una zona específica.",
    privs = {server=true},
    func = function(name, param)
        local id = tonumber(param)
        if not id then return false, "Uso: /limpiar_zona <id>" end
        local ok, msg = zonas.limpiar_zona(id)
        return ok, msg
    end
})

-- Comando: /limpiar_zonas
minetest.register_chatcommand("limpiar_zonas", {
    description = "Limpia todas las zonas.",
    privs = {server=true},
    func = function(name)
        for i = 1, #zonas.lista do
            zonas.limpiar_zona(i)
        end
        return true, "🧹 Todas las zonas fueron limpiadas."
    end
})
minetest.register_chatcommand("generar_zonas", {
    description = "Recalcula posiciones debajo del spawn y genera zonas.",
    privs = {server=true},
    func = function(name)
        zonas.generar_zonas()
        return true, "✅ Zonas recalculadas y generadas debajo del spawn."
    end
})
minetest.register_chatcommand("ver_zonas", {
    description = "Muestra coordenadas de centros de zona.",
    privs = {server=true},
    func = function(name)
        for i, z in ipairs(zonas.lista) do
            minetest.chat_send_player(name, "Zona " .. i .. " (" .. z.nombre .. "): " .. util.str_pos(z.centro))
        end
        return true
    end
})
minetest.register_chatcommand("separacion_zonas", {
    params = "<valor>",
    description = "Ajusta la distancia entre zonas.",
    privs = {server=true},
    func = function(name, param)
        local val = tonumber(param)
        if not val or val < 1 then return false, "Debe ser un número mayor a 0." end
        config.zona.separacion = val
      --  persist.registrar_evento("ZONAS", name, "Separación entre zonas ajustada a " .. val)
        return true, "📐 Separación entre zonas actualizada a " .. val
    end
})
minetest.register_chatcommand("tp_zona", {
    params = "<n>",
    description = "Teletransporta al centro de la zona N.",
    privs = {server=true},
    func = function(name, param)
        local id = tonumber(param)
        local player = minetest.get_player_by_name(name)
        if not id or not player then return false, "Uso: /tp_zona <n>" end
        local z = zonas.lista[id]
        if not z then return false, "Zona no encontrada." end
        player:set_pos({x = z.centro.x, y = z.centro.y + 5, z = z.centro.z})
        return true, "🚀 Teletransportado a zona " .. id
    end
})
minetest.register_chatcommand("tamano_zona", {
    params = "<ancho> <alto>",
    description = "Establece tamaño de las zonas.",
    privs = {server=true},
    func = function(name, param)
        local a, h = string.match(param, "^(%d+)%s+(%d+)$")
        a, h = tonumber(a), tonumber(h)
        if not a or not h or a < config.zona.min_ancho or h < 1 then
            return false, "Valores inválidos. Mínimo ancho: " .. config.zona.min_ancho
        end
        config.zona.ancho = a
        config.zona.alto = h
        zonas.generar_zonas()
        return true, "📐 Tamaño de zonas actualizado a " .. a .. "x" .. h
    end
})
minetest.register_chatcommand("ver_tamano_zona", {
    description = "Muestra tamaño actual de las zonas.",
    privs = {server=true},
    func = function(name)
        local a = config.zona.ancho
        local h = config.zona.alto
        return true, "📏 Tamaño actual de zonas: " .. a .. "x" .. h
    end
})
minetest.register_chatcommand("ver_spawn", {
    description = "Muestra el spawn activo.",
    privs = {server=true},
    func = function(name)
        local pos = zonas.get_spawn_global()
        return true, "📍 Spawn actual: " .. util.str_pos(pos)
    end
})

minetest.register_chatcommand("definir_spawn", {
    params = "[x y z]",
    description = "Guarda una posición como spawn (si no: tu posición actual).",
    privs = {server=true},
    func = function(name, param)
        local player = minetest.get_player_by_name(name)
        if not player then return false, "Jugador no encontrado." end

        local x, y, z = string.match(param, "^(%-?%d+)%s+(%-?%d+)%s+(%-?%d+)$")
        local pos
        if x and y and z then
            pos = {x = tonumber(x), y = tonumber(y), z = tonumber(z)}
        else
            pos = player:get_pos()
        end

        zonas.definir_spawn(pos)
        return true, "✅ Spawn definido en " .. util.str_pos(pos)
    end
})
return zonas
