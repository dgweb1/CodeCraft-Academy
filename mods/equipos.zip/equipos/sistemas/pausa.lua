-- =========================================
-- SISTEMA DE PAUSA / CASTIGO TEMPORAL
-- =========================================

local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")

local pausa = {}
local pausados = {}

function pausa.pausar(nombre, minutos)
    local p = minetest.get_player_by_name(nombre)
    if not p then return false, "Jugador no encontrado." end
    local pos = p:get_pos()
    p:set_pos({x = pos.x, y = pos.y + 100, z = pos.z})
    pausados[nombre] = {tiempo = os.time(), minutos = minutos or 2, pos_original = pos}
    persist.registrar_evento("PAUSA", nombre, "Pausado por " .. (minutos or 2) .. " min")
    return true, nombre .. " pausado."
end

function pausa.verificar()
    for n, d in pairs(pausados) do
        if os.difftime(os.time(), d.tiempo) >= (d.minutos * 60) then
            local p = minetest.get_player_by_name(n)
            if p then p:set_pos(d.pos_original) end
            pausados[n] = nil
            persist.registrar_evento("LIBERADO", n, "Regresó de pausa.")
        end
    end
end

minetest.register_globalstep(function()
    pausa.verificar()
end)

return pausa
