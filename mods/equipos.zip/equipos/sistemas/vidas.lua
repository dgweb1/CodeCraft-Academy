-- =========================================
-- SISTEMA DE VIDAS LIMITADAS
-- =========================================

local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")
local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")

local vidas = {}
local vidas_max = config.vidas_max or 5
local vidas_jugadores = {}

-- 🧍 Al entrar, asignar vidas
minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    if not vidas_jugadores[name] then
        vidas_jugadores[name] = vidas_max
    end
end)

-- 💀 Al morir, reducir vidas
minetest.register_on_dieplayer(function(player)
    local name = player:get_player_name()
    if not vidas_jugadores[name] then return end
    vidas_jugadores[name] = vidas_jugadores[name] - 1
    persist.registrar_evento("VIDA", name, "Perdió una vida (" .. vidas_jugadores[name] .. " restantes)")
    if vidas_jugadores[name] <= 0 then
        minetest.kick_player(name, "Sin vidas restantes.")
    end
end)

-- 🔧 Cambiar número máximo
minetest.register_chatcommand("vidas", {
    params = "<número>",
    description = "Establece el número máximo de vidas por jugador.",
    privs = {server=true},
    func = function(name, param)
        local n = tonumber(param)
        if not n or n < 1 then return false, "Debe ser un número mayor a 0." end
        vidas_max = n
        config.vidas_max = n
        persist.guardar_config(config)
        return true, "✅ Número de vidas establecido en " .. n
    end
})

-- 👁️ Ver vidas actuales
minetest.register_chatcommand("ver_vidas", {
    description = "Muestra las vidas de todos los jugadores.",
    privs = {server=true},
    func = function(name)
        for jugador, v in pairs(vidas_jugadores) do
            minetest.chat_send_player(name, jugador .. ": " .. v .. " vidas restantes")
        end
    end
})

return vidas
