-- =========================================
-- SISTEMA DE PARTIDAS Y EQUIPOS
-- =========================================

local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")
local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")
local zonas = dofile(minetest.get_modpath("equipos") .. "/sistemas/zonas.lua")

local partida = {}
local asignaciones = {}

-- 🏁 Iniciar partida
function partida.iniciar(tam)
    local zonas_equipo = zonas.lista
    if not zonas_equipo or #zonas_equipo == 0 then
        zonas.generar_zonas()
    end

    local online = {}
    for _, p in ipairs(minetest.get_connected_players()) do
        local n = p:get_player_name()
        if not util.es_administrador(n) then
            table.insert(online, n)
        end
    end

    if #online == 0 then return false, "No hay estudiantes conectados." end

    -- Mezclar lista
    for i = #online, 2, -1 do
        local j = math.random(i)
        online[i], online[j] = online[j], online[i]
    end

    local total_zonas = #zonas_equipo
    local grupo = 1
    local idx = 1

    if tam == 1 then
        -- Distribución automática por zonas
        local por_zona = math.floor(#online / total_zonas)
        local resto = #online % total_zonas
        for z = 1, total_zonas do
            local cantidad = por_zona + (resto > 0 and 1 or 0)
            if resto > 0 then resto = resto - 1 end
            for i = 1, cantidad do
                if online[idx] then
                    local pname = online[idx]
                    local player = minetest.get_player_by_name(pname)
                    local zona = zonas_equipo[z]
                    if player and zona then
                        asignaciones[pname] = zona.nombre
                        player:set_pos({x = zona.centro.x, y = zona.centro.y + config.zona.alto + 1, z = zona.centro.z})
                        util.asignar_skin(player, zona.skin)
                        persist.registrar_evento("EQUIPO", pname, "Asignado a " .. zona.nombre)
                    end
                    idx = idx + 1
                end
            end
        end
        return true, "Partida iniciada con distribución automática por zonas."
    else
        -- Distribución por tamaño fijo (3 o 5)
        while idx <= #online do
            for k = 1, tam do
                if online[idx] then
                    local pname = online[idx]
                    local player = minetest.get_player_by_name(pname)
                    if player then
                        local zona_idx = ((grupo - 1) % total_zonas) + 1
                        local zona = zonas_equipo[zona_idx]
                        asignaciones[pname] = zona.nombre
                        player:set_pos({x = zona.centro.x, y = zona.centro.y + config.zona.alto + 1, z = zona.centro.z})
                        util.asignar_skin(player, zona.skin)
                        persist.registrar_evento("EQUIPO", pname, "Asignado a " .. zona.nombre)
                    end
                    idx = idx + 1
                end
            end
            grupo = grupo + 1
        end
        return true, "Partida iniciada con equipos de " .. tam
    end
end

-- 🔄 Reset
function partida.reset()
    for _, p in ipairs(minetest.get_connected_players()) do
        local pname = p:get_player_name()
        if not util.es_administrador(pname) then
            p:set_pos(zonas.spawn_global)
            util.asignar_skin(p, config.skin_default)
        end
    end
    asignaciones = {}
    persist.registrar_evento("RESET", "-", "Partida reiniciada")
end
minetest.register_chatcommand("iniciar_partida", {
    params = "<3|5>",
    description = "Asigna equipos y teletransporta jugadores.",
    privs = {server=true},
    func = function(name, param)
        local tam = tonumber(param)
        if not tam or (tam ~= 3 and tam ~= 5) then
            return false, "Uso: /iniciar_partida <3|5>"
        end
        local ok, msg = partida.iniciar(tam)
        return ok, msg
    end
})

minetest.register_chatcommand("reset_partida", {
    description = "Restablece el estado inicial de la partida.",
    privs = {server=true},
    func = function(name)
        partida.reset()
        return true, "🔄 Partida reiniciada."
    end
})

-- Comando: /ver_equipos
minetest.register_chatcommand("ver_equipos", {
    description = "Muestra los equipos asignados en la partida actual.",
    privs = {server=true},
    func = function(name)
        if not asignaciones or next(asignaciones) == nil then
            return true, "No hay asignaciones activas."
        end
        for jugador, equipo in pairs(asignaciones) do
            minetest.chat_send_player(name, jugador .. " → " .. equipo)
        end
        return true
    end
})

return partida
