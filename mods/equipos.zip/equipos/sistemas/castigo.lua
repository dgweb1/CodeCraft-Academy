-- =========================================
-- SISTEMA DE CASTIGO
-- =========================================

local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")
local persist = dofile(minetest.get_modpath("equipos") .. "/core/persistencia.lua")
local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")

local castigo = {
    zona = config.spawn_castigo or {x = 0, y = 10, z = 0}
}

-- 🔨 Definir zona de castigo
minetest.register_chatcommand("definir_castigo", {
    description = "Define la ubicación actual como zona de castigo.",
    privs = {server=true},
    func = function(name)
        local player = minetest.get_player_by_name(name)
        if not player then return false, "Jugador no encontrado" end
        castigo.zona = player:get_pos()
        config.spawn_castigo = castigo.zona
        persist.guardar_config(config)
        persist.registrar_evento("CASTIGO", name, "Definió nueva zona de castigo en " .. util.str_pos(castigo.zona))
        return true, "✅ Zona de castigo definida en " .. util.str_pos(castigo.zona)
    end
})

-- 👁️ Ver zona de castigo
minetest.register_chatcommand("ver_castigo", {
    description = "Muestra la ubicación de la zona de castigo actual.",
    privs = {server=true},
    func = function(name)
        minetest.chat_send_player(name, "📍 Zona de castigo: " .. util.str_pos(castigo.zona))
        return true
    end
})

-- 💢 Castigar jugador manualmente
minetest.register_chatcommand("castigar", {
    params = "<nombre>",
    description = "Envía a un jugador a la zona de castigo.",
    privs = {server=true},
    func = function(name, param)
        local p = minetest.get_player_by_name(param)
        if not p then return false, "Jugador no encontrado" end
        p:set_pos(castigo.zona)
        persist.registrar_evento("CASTIGO", param, "Enviado a la zona de castigo por " .. name)
        return true, "⚠ " .. param .. " fue enviado a la zona de castigo."
    end
})

return castigo
