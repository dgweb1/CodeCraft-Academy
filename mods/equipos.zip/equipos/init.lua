-- =========================================
-- MOD: equipos
-- Estructura modular (núcleo + sistemas + comandos)
-- =========================================

local modpath = minetest.get_modpath("equipos")

-- ===== Carga del núcleo =====
dofile(modpath .. "/core/config.lua")
dofile(modpath .. "/core/util.lua")
dofile(modpath .. "/core/persistencia.lua")

-- ===== Carga de sistemas =====
dofile(modpath .. "/sistemas/zonas.lua")
dofile(modpath .. "/sistemas/partida.lua")
dofile(modpath .. "/sistemas/castigo.lua")
dofile(modpath .. "/sistemas/respawn.lua")
dofile(modpath .. "/sistemas/pausa.lua")
dofile(modpath .. "/sistemas/inventario.lua")
dofile(modpath .. "/sistemas/vidas.lua")
dofile(modpath .. "/sistemas/usuarios.lua")

-- ===== Carga de comandos =====
dofile(modpath .. "/comandos/ayuda.lua")
dofile(modpath .. "/comandos/configuracion.lua")

-- ===== Mensaje de carga =====
minetest.log("action", "[EQUIPOS] Módulo cargado con estructura modular completa.")
-- ----------------------------------------
-- Acciones post-carga: asegurar spawn y ayuda
-- ----------------------------------------

local modpath = minetest.get_modpath("equipos")
-- cargar config y util (ya deberían estar cargados, pero lo pedimos de forma segura)
local config = dofile(modpath .. "/core/config.lua")
local util = dofile(modpath .. "/core/util.lua")
local zonas = dofile(modpath .. "/sistemas/zonas.lua")

-- 1) asegurar spawn default (si no existe), y crear base 3x3x1
if not config.spawn_global or not config.spawn_global.x then
    config.spawn_global = {x = 0, y = 50, z = 0}
end
-- crear base segura en el spawn por defecto (3x3x1)
zonas.crear_base_spawn(config.spawn_global)

-- 2) registrar /ayuda (si el comando de ayuda ya fue cargado esto no hace nada extra)
-- (comandos/ayuda.lua ya registra /ayuda por sí mismo; aseguramos que util funcione)
minetest.log("action", "[equipos] Spawn por defecto asegurado en " .. util.str_pos(config.spawn_global))

