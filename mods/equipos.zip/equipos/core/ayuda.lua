-- comandos/ayuda.lua
-- Muestra todos los comandos disponibles del mod "equipos"

local util = dofile(minetest.get_modpath("equipos") .. "/core/util.lua")

local ayuda_text = [[
📘 COMANDOS DEL MOD "equipos"

🧑‍🏫 Administración (solo admins)
  /iniciar_partida <3|5>     - Asigna equipos y teletransporta
  /reset_partida             - Restablece el estado inicial

🧱 Zonas (admins)
  /crear_zona <n> [mat]      - Crea la plataforma de una zona
  /crear_zonas [mat]         - Crea todas las plataformas
  /limpiar_zona <n>          - Elimina la plataforma de una zona
  /limpiar_zonas             - Elimina todas las plataformas
  /generar_zonas             - Recalcula posiciones debajo del spawn
  /ver_zonas                 - Muestra coordenadas de centros de zona
  /separacion_zonas <val>    - Ajusta la distancia entre zonas
  /tp_zona <n>               - Teletransporta a una zona

📐 Tamaño (admins)
  /tamano_zona <base> <altura> - Establece tamaño (base = ancho/largo)
  /ver_tamano_zona             - Muestra tamaño actual

🚀 Spawn (admins)
  /definir_spawn [x y z]     - Guarda una posición como spawn (si no: tu pos)
  /ver_spawn                 - Muestra el spawn activo
  /ver_spawns                - Muestra todos los spawns guardados
  /elegir_spawn <id>         - Establece un spawn como activo
  /definir_castigo           - Guarda la ubicación actual como zona de castigo
  /ver_castigo               - Muestra la zona de castigo

⚙️ Reaparición (admins)
  /modo_respawn <global|castigo|muerte> - Configura cómo reaparecen

👥 Usuarios (admins)
  /usuarios                  - Muestra conectados
  /usuarios_permitidos       - Muestra lista blanca
  /pausar <nombre> [min]     - Pausa a un jugador
  /liberar <nombre>          - Libera a un jugador pausado
  /pausados                  - Muestra jugadores pausados
  /limite_bloques [n]        - Ajusta límite de bloques por jugador

🧾 Miscelánea
  /ver_eventos               - Muestra últimos eventos guardados
  /limpiar_eventos           - Limpia el log de eventos (admins)
  /ayuda                     - Este menú
]]

minetest.register_chatcommand("ayuda", {
    description = "Muestra todos los comandos disponibles del mod 'equipos'.",
    func = function(name)
        -- si es jugador offline, sólo se muestra por consola; pero normalmente es player.
        util.send_multiline(name, ayuda_text)
        return true
    end
})
