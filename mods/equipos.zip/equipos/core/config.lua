-- =========================================
-- CONFIGURACIÓN GENERAL DEL MOD "equipos"
-- =========================================

local config = {}

-- 🌍 SPAWN PREDETERMINADO
config.spawn_global = {x = 0, y = 50, z = 0}

-- ⚙️ PARÁMETROS DE ZONAS
config.zona = {
    ancho = 20,
    alto = 10,
    separacion = 20,
    material_default = "default:stone",
    min_ancho = 3,
    max_ancho = 100,
    max_alto = 50
}
-- 🧱 Zonas predefinidas (15) ESTO LO INCORPORE YO !!!
config.zonas_equipo = {
    {nombre = "Equipo Alfa",   skin = "character_1",  material = "default:stone",      centro = {x = -100, y = 5, z = -5}},
    {nombre = "Equipo Beta",   skin = "character_2",  material = "default:wood",       centro = {x = -50,  y = 5, z = -5}},
    {nombre = "Equipo Gamma",  skin = "character_3",  material = "default:glass",      centro = {x = 0,    y = 5, z = -5}},
    {nombre = "Equipo Delta",  skin = "character_4",  material = "default:sandstone",  centro = {x = 50,   y = 5, z = -5}},
    {nombre = "Equipo Épsilon",skin = "character_5",  material = "default:brick",      centro = {x = 100,  y = 5, z = -5}},
    {nombre = "Equipo Zeta",   skin = "character_6",  material = "default:steelblock", centro = {x = -100, y = 5, z = 45}},
    {nombre = "Equipo Eta",    skin = "character_7",  material = "default:clay",       centro = {x = -50,  y = 5, z = 45}},
    {nombre = "Equipo Theta",  skin = "character_8",  material = "default:obsidian",   centro = {x = 0,    y = 5, z = 45}},
    {nombre = "Equipo Iota",   skin = "character_9",  material = "default:desert_sand",centro = {x = 50,   y = 5, z = 45}},
    {nombre = "Equipo Kappa",  skin = "character_10", material = "default:snowblock",  centro = {x = 100,  y = 5, z = 45}},
    {nombre = "Equipo Lambda", skin = "character_11", material = "default:dirt",       centro = {x = -100, y = 5, z = 95}},
    {nombre = "Equipo Mu",     skin = "character_12", material = "default:ice",        centro = {x = -50,  y = 5, z = 95}},
    {nombre = "Equipo Nu",     skin = "character_13", material = "default:desert_stone",centro = {x = 0,   y = 5, z = 95}},
    {nombre = "Equipo Xi",     skin = "character_14", material = "default:junglewood", centro = {x = 50,   y = 5, z = 95}},
    {nombre = "Equipo Omicron",skin = "character_15", material = "default:goldblock",  centro = {x = 100,  y = 5, z = 95}},
}

-- 👑 ADMINISTRADORES
config.administradores = {"creador", "profe_daniel", "admin"}

-- 👥 USUARIOS PERMITIDOS
config.usuarios_permitidos = {}
for i = 1, 50 do
    table.insert(config.usuarios_permitidos, "estudiante" .. i)
end
for _, adm in ipairs(config.administradores) do
    table.insert(config.usuarios_permitidos, adm)
end

-- 💀 CONFIGURACIÓN DE VIDAS
config.max_vidas = 3

-- 🧱 LÍMITE DE BLOQUES
config.max_bloques = 10

-- 🧍‍♂️ SKIN POR DEFECTO
config.skin_default = "character_1"

-- ⚔️ CASTIGO
config.spawn_castigo = {x = 1000, y = 5, z = 1000}

-- 🪦 REAPARICIÓN
config.modo_respawn = "global" -- opciones: "global", "castigo", "muerte"

-- 📂 ARCHIVOS DE LOGS
config.ruta_logs = minetest.get_worldpath() .. "/equipos_logs"

return config






