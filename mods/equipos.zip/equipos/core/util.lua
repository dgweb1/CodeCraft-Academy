-- =========================================
-- 🧩 UTILIDADES GENERALES
-- =========================================
local util = {}

-- ✅ Verificar si un jugador es administrador
function util.es_administrador(name)
    local config = dofile(minetest.get_modpath("equipos") .. "/core/config.lua")
    for _, adm in ipairs(config.administradores or {}) do
        if adm == name then
            return true
        end
    end
    return false
end

-- 🧾 Formatear coordenadas a texto
function util.str_pos(pos)
    if not pos then return "(nil)" end
    return string.format("(x=%.1f, y=%.1f, z=%.1f)", pos.x, pos.y, pos.z)
end

-- 💬 Enviar mensajes multilínea al chat
function util.send_multiline(playername, text)
    if not text then return end
    for line in string.gmatch(text, "[^\n]+") do
        minetest.chat_send_player(playername, line)
    end
end

-- 🧍 Obtener nombre y posición de todos los jugadores conectados
function util.obtener_jugadores_conectados()
    local players = {}
    for _, p in ipairs(minetest.get_connected_players()) do
        table.insert(players, {
            nombre = p:get_player_name(),
            pos = p:get_pos()
        })
    end
    return players
end

-- 📦 Crear una base sólida bajo un punto (por ejemplo spawn)
function util.crear_base_solida(pos, material)
    material = material or "default:stone"
    for dx = -1, 1 do
        for dz = -1, 1 do
            local npos = {x = pos.x + dx, y = pos.y - 1, z = pos.z + dz}
            minetest.set_node(npos, {name = material})
        end
    end
end

-- 🕐 Formatear hora para registros
function util.timestamp()
    return os.date("%Y-%m-%d %H:%M:%S")
end

return util
