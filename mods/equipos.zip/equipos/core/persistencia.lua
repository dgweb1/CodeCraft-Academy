-- core/persistencia.lua
local persistencia = {}

local config_path = minetest.get_worldpath() .. "/config_guardada.lua"
local eventos_path = minetest.get_worldpath() .. "/eventos.txt"

-- Guardar configuración
function persistencia.guardar_config(config)
    local file = io.open(config_path, "w")
    if file then
        file:write("return " .. minetest.serialize(config))
        file:close()
    end
end

-- Cargar configuración
function persistencia.cargar_config()
    local f = io.open(config_path, "r")
    if f then
        local contenido = f:read("*a")
        f:close()
        local cargado = loadstring(contenido)
        if cargado then
            return cargado()
        end
    end
    return {}
end

-- Registrar evento
function persistencia.registrar_evento(tipo, jugador, mensaje)
    local f = io.open(eventos_path, "a")
    if f then
        local linea = os.date("[%Y-%m-%d %H:%M:%S]") .. " [" .. tipo .. "] " .. jugador .. ": " .. mensaje .. "\n"
        f:write(linea)
        f:close()
    end
end

-- Limpiar eventos
function persistencia.limpiar_eventos()
    local f = io.open(eventos_path, "w")
    if f then f:close() end
end

-- Ver eventos
function persistencia.ver_eventos(name)
    local f = io.open(eventos_path, "r")
    if not f then return true, "No hay eventos registrados." end
    local contenido = f:read("*a")
    f:close()
    return true, contenido
end

return persistencia